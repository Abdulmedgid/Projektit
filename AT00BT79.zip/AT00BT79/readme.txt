Siirrä tämä kansio alikansioineen niiskuun public_html-kansioon. Mene puttylla tai 
terminalilla niiskulle ja siirry AT00BT79 kansioon ja anna komento pwd. Sen pitäisi 
tulostaa kansiopolku /home/omakäyttäjänimesi/public_html/AT00BT79/. Jos tämä on oikein 
niin homma pitäisi toimia.

Korvaa kunkin kansion sisältö annetulla harkalla body-tagin sisällä olevalta osalta. 
Katso että css, js ym. tiedostot linkittyvät oikein kussakin harkassa.